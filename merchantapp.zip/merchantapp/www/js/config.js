
var krms_config ={
	'ApiUrl' : "http://boozeit.co.ke/merchantapp/api",
	'DialogDefaultTitle' : "Boozeit",
	'pushNotificationSenderid' : "39683464570",
	'APIHasKey' : "YOUR API HASH KEY (OPTIONAL)"
};
